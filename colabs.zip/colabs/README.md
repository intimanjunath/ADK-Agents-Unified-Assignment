# Team NextGen

# Project Members
* Apurva Karne
* Jayanth Kalyanam 
* Manjunatha Inti
* Praful John

# Summary of Team Contributions
--<--To be modified-->--
1. Apurva Karne
2. Jayanth Kalyanam 
3. Manjunatha Inti
4. Praful John

# Project Journal link

# Product Backlog and Sprint Backog link
[Sprint-Product-Backlog](https://docs.google.com/spreadsheets/d/1LfWwaJk3pdDYSQI4CuukW5ODS8gR5g_ZOushuVRgMc8/edit?usp=sharing)

[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Fu_pncF5)

